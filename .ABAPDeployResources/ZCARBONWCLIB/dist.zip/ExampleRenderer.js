/*!
 * ${copyright}
 */
sap.ui.define(["sap/ui/core/Core","./library"],function(e,i){"use strict";var r=i.ExampleColor;var t={apiVersion:2};t.render=function(i,t){var a=e.getLibraryResourceBundle("zcarbonwclib");i.openStart("div",t);if(t.getColor()===r.Highlight){i.class("myLibPrefixExampleHighlight")}else{i.class("myLibPrefixExample")}i.openEnd();i.text(a.getText("ANY_TEXT")+": "+t.getText());i.close("div")};return t});