/*!
 * ${copyright}
 */
sap.ui.define(["sap/ui/core/library","./bundle"],function(){"use strict";sap.ui.getCore().initLibrary({name:"zcarbonwclib",version:"1.0.0",dependencies:["sap.ui.core"],types:["zcarbonwclib.ExampleColor"],interfaces:[],controls:["zcarbonwclib.Example","zcarbonwclib.CarbonButton","zcarbonwclib.CarbonProgressIndicator","zcarbonwclib.CarbonProgressStep"],elements:[],noLibraryCSS:false});var r=zcarbonwclib;r.ExampleColor={Default:"Default",Highlight:"Highlight"};return r});