/*!
 * ${copyright}
 */
sap.ui.define(["sap/m/library","sap/ui/Device","sap/ui/core/InvisibleText","./CarbonProgressStepRenderer"],function(e,r,t){"use strict";var i={apiVersion:2};i.render=function(e,r){e.openStart("bx-progress-indicator",r);if(r.getDisabled()){e.attr("disabled")}if(r.getVertical()){e.attr("vertical")}e.openEnd();var t=r.getSteps();for(var i=0;i<t.length;i++){e.renderControl(t[i])}e.close("bx-progress-indicator")};return i},true);