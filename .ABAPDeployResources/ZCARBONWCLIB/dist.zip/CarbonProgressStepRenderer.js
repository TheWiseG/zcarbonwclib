/*!
 * ${copyright}
 */
sap.ui.define(["sap/m/library","sap/ui/Device","sap/ui/core/InvisibleText"],function(e,t){"use strict";var a={apiVersion:2};a.render=function(e,t){e.openStart("bx-progress-step",t);if(t.getDisabled()){e.attr("disabled")}e.attr("state",t.getState());e.attr("label-text",t.getLabelText());e.attr("secondary-label-text",t.getSecondaryLabelText());e.openEnd();e.close("bx-progress-step")};return a},true);